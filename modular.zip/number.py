def first():
    first = int(input("Please input your first number "))

def second():
    second = int(input("Now enter your second number "))
    
