def plus():
    print(first + second)

def minus():
    print(first - second)

def multiply():
    print(first * second)

def divide():
    print(first / second)
