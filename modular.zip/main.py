import number

number.first()
number.second()

import process

process.plus()
process.minus()
process.multiply()
process.divide()


file = open('Answer.txt','w')
file.write('The sum of 5 and 5 is 10\n The difference between 5 and 5 is 5\n The product of 5 and 5 is 25\n The quotient of 5 and 5 is 1')
